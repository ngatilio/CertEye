import { Cxa } from ".";

export default {
  title: "Components/Cxa",
  component: Cxa,
};

export const Default = {
  args: {
    className: {},
    text: "Enter URL",
    overlapGroupClassName: {},
    text1: "www.textlink.com",
  },
};
