import { LightDoughnutChart } from ".";

export default {
  title: "Components/LightDoughnutChart",
  component: LightDoughnutChart,
};

export const Default = {
  args: {
    className: {},
  },
};
