import React from "react";
import "./style.css";

export const Box = () => {
  return (
    <div className="box">
      <div className="rectangle" />
    </div>
  );
};
