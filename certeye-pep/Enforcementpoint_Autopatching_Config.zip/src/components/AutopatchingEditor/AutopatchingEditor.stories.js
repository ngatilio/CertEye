import { AutopatchingEditor } from ".";

export default {
  title: "Components/AutopatchingEditor",
  component: AutopatchingEditor,
};

export const Default = {
  args: {
    className: {},
  },
};
