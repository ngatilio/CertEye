import { Python } from ".";

export default {
  title: "Components/Python",
  component: Python,
};

export const Default = {
  args: {
    className: {},
  },
};
