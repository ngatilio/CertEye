import { LightLineChart } from ".";

export default {
  title: "Components/LightLineChart",
  component: LightLineChart,
};

export const Default = {
  args: {
    className: {},
  },
};
