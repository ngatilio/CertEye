import { NewPassword } from ".";

export default {
  title: "Components/NewPassword",
  component: NewPassword,
};

export const Default = {
  args: {
    className: {},
  },
};
