export { Property1DeactiveState } from "./Property1DeactiveState";
