import React from "react";
import ReactDOMClient from "react-dom/client";
import { AiTool } from "./screens/AiTool";

const app = document.getElementById("app");
const root = ReactDOMClient.createRoot(app);
root.render(<AiTool />);
