export { AiEthicsConfim } from "./AiEthicsConfim";
