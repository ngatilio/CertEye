export { NewPassword } from "./NewPassword";
