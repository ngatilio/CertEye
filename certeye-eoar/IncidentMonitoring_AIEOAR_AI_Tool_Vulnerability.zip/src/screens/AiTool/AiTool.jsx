import React from "react";
import { Header } from "../../components/Header";
import { Menu } from "../../components/Menu";
import "./style.css";

export const AiTool = () => {
  return (
    <div className="AI-tool">
      <div className="div-4">
        <div className="overlap-2">
          <div className="frame-7">
            <div className="navbar">
              <div className="JC">YAML</div>
              <div className="JC-2">01</div>
              <div className="JC-3">Tensor flow</div>
              <div className="JC-4">High</div>
            </div>
            <img className="line-4" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-8">
            <div className="navbar-2">
              <div className="JC-5">sqlite3</div>
              <div className="JC-6">16</div>
              <div className="JC-7">Openray</div>
              <div className="JC-8">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-9">
            <div className="navbar-3">
              <div className="JC-5">libjepeg</div>
              <div className="JC-9">04</div>
              <div className="JC-10">Ray</div>
              <div className="JC-11">medium</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-10">
            <div className="navbar-4">
              <div className="JC-5">giflib</div>
              <div className="JC-12">01</div>
              <div className="JC-13">Nni</div>
              <div className="JC-14">medium</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-11">
            <div className="navbar-5">
              <div className="JC-5">icu</div>
              <div className="JC-15">01</div>
              <div className="JC-16">Pytorch</div>
              <div className="JC-17">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-12">
            <div className="navbar-6">
              <div className="JC-5">libjepeg_9c</div>
              <div className="JC-18">01</div>
              <div className="JC-19">Pandas</div>
              <div className="JC-20">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-13">
            <div className="group-16">
              <div className="JC-5">libjepng</div>
              <div className="JC-21">01</div>
              <div className="JC-22">Numphy</div>
              <div className="JC-23">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-14">
            <div className="group-17">
              <div className="JC-5">lua54</div>
              <div className="JC-24">05</div>
              <div className="JC-3">mxnet</div>
              <div className="JC-4">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-15">
            <div className="group-18">
              <div className="JC-5">pickle</div>
              <div className="JC-24">04</div>
              <div className="JC-3">gym</div>
              <div className="JC-4">Critical</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-16">
            <div className="group-19">
              <div className="JC-5">requests</div>
              <div className="JC-25">01</div>
              <div className="JC-26">scikit-learn</div>
              <div className="JC-27">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-17">
            <div className="group-20">
              <div className="JC-5">pyyaml</div>
              <div className="JC-28">01</div>
              <div className="JC-29">Keras</div>
              <div className="JC-30">Medium</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-18">
            <div className="group-21">
              <div className="JC-5">pillow</div>
              <div className="JC-2">01</div>
              <div className="JC-3">deeplearnin-4g</div>
              <div className="JC-4">Low</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-19">
            <div className="group-22">
              <div className="JC-5">log4j</div>
              <div className="JC-12">01</div>
              <div className="JC-13">Tensor flow</div>
              <div className="JC-14">Low</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-20">
            <div className="group-23">
              <div className="JC-5">numpy116</div>
              <div className="JC-31">01</div>
              <div className="JC-32">Openray</div>
              <div className="JC-33">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-21">
            <div className="group-24">
              <div className="JC-5">joblib</div>
              <div className="JC-34">03</div>
              <div className="JC-35">Pytorch</div>
              <div className="JC-36">Medium</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-22">
            <div className="group-25">
              <div className="JC-5">libsvm</div>
              <div className="JC-37">04</div>
              <div className="JC-38">Keras</div>
              <div className="JC-39">Medium</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-23">
            <div className="group-26">
              <div className="JC-5">python391</div>
              <div className="JC-40">17</div>
              <div className="JC-41">mxnet</div>
              <div className="JC-42">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <div className="frame-24">
            <div className="group-27">
              <div className="JC-5">jquery211</div>
              <div className="JC-43">01</div>
              <div className="JC-44">gym</div>
              <div className="JC-45">High</div>
            </div>
            <img className="line-5" alt="Line" src="/img/line-5.svg" />
          </div>
          <img className="line-6" alt="Line" src="/img/line-4.svg" />
          <div className="JC-46">Dependency</div>
          <div className="JC-47">Affected repos</div>
          <div className="JC-48">
            Vulner, num
            <br />
            caused
          </div>
          <div className="JC-49">Severity (avg)</div>
          <p className="add-a-new-company">Statistics about the AI incidents detected.</p>
          <div className="overlap-3">
            <div className="chart">
              <img className="divider" alt="Divider" src="/img/divider.svg" />
              <div className="identifiers">
                <div className="label">
                  <div className="name">tensor flow</div>
                  <div className="identifier" />
                </div>
                <div className="label-2">
                  <div className="name">opencv</div>
                  <div className="identifier-2" />
                </div>
                <div className="label-3">
                  <div className="name">ray</div>
                  <div className="identifier-3" />
                </div>
                <div className="label-3">
                  <div className="name">nni</div>
                  <div className="identifier-4" />
                </div>
                <div className="label-4">
                  <div className="name">pytorch</div>
                  <div className="identifier-5" />
                </div>
                <div className="label-2">
                  <div className="name">pandas</div>
                  <div className="identifier-3" />
                </div>
                <div className="label-5">
                  <div className="name">numphy</div>
                  <div className="identifier-6" />
                </div>
                <div className="label-6">
                  <div className="name">mxnet</div>
                  <div className="identifier-7" />
                </div>
              </div>
              <img className="pie" alt="Pie" src="/img/pie.png" />
              <div className="card-info">
                <div className="type-card">Statistics</div>
                <div className="card-title">Affected respositories</div>
              </div>
            </div>
            <div className="label-7">
              <div className="name">gym</div>
              <div className="identifier-8" />
            </div>
            <div className="label-8">
              <div className="name">mlflow</div>
              <div className="identifier-9" />
            </div>
            <div className="label-9">
              <div className="name">scikit_learn</div>
              <div className="identifier-10" />
            </div>
            <div className="label-10">
              <div className="name">keras</div>
              <div className="identifier-11" />
            </div>
            <div className="label-11">
              <div className="name">deeplearnin 4j</div>
              <div className="identifier-12" />
            </div>
          </div>
          <div className="overlap-4">
            <div className="chart">
              <img className="divider" alt="Divider" src="/img/divider.svg" />
              <div className="identifiers-2">
                <div className="label-12">
                  <div className="name">Critical</div>
                  <div className="identifier-13" />
                </div>
                <div className="label-13">
                  <div className="name">High</div>
                  <div className="identifier-14" />
                </div>
                <div className="label-14">
                  <div className="name">Medium</div>
                  <div className="identifier-15" />
                </div>
                <div className="label-15">
                  <div className="name">Low</div>
                  <div className="identifier-16" />
                </div>
              </div>
              <div className="card-info-2">
                <div className="type-card">Statistics</div>
                <p className="card-title">Total level of severity per repositories</p>
              </div>
            </div>
            <div className="doughnut">
              <div className="overlap-group-3">
                <img className="element" alt="Element" src="/img/01.svg" />
                <img className="element-2" alt="Element" src="/img/02.svg" />
                <img className="element-3" alt="Element" src="/img/03.svg" />
                <img className="element-4" alt="Element" src="/img/04.svg" />
              </div>
            </div>
          </div>
        </div>
        <div className="navbar-7">
          <div className="text-wrapper-5">Incident monitoring</div>
          <div className="text-wrapper-6">AI EOAR</div>
          <div className="text-wrapper-7">/</div>
          <div className="text-wrapper-8">/</div>
          <div className="text-wrapper-9">AI Tool vulnerability</div>
        </div>
        <Menu
          className="menu-instance"
          customerClassName="design-component-instance-node"
          customerClassNameOverride="design-component-instance-node"
          divClassName="menu-2"
          divClassName1="menu-4"
          divClassName2="menu-4"
          divClassNameOverride="menu-3"
          frame="/img/frame-128.svg"
          iconsaxLinear="/img/iconsax-linear-useroctagon.svg"
          iconsaxLinear1="/img/iconsax-linear-setting2.svg"
          iconsaxLinear10="/img/iconsax-linear-activity.svg"
          iconsaxLinear2="/img/iconsax-linear-arrowright2-4.svg"
          iconsaxLinear3="/img/iconsax-linear-profile2user.svg"
          iconsaxLinear4="/img/iconsax-linear-arrowright2-3.svg"
          iconsaxLinear5="/img/iconsax-linear-arrowright2-2.svg"
          iconsaxLinear6="/img/iconsax-linear-building4.svg"
          iconsaxLinear7="/img/iconsax-linear-documenttext1.svg"
          iconsaxLinear8="/img/iconsax-linear-arrowright2-1.svg"
          iconsaxLinear9="/img/iconsax-linear-arrowright2.svg"
          img="/img/iconsax-linear-arrowright2-4.svg"
          property1="EOAR"
        />
        <Header
          className="header-instance"
          iconsaxLinear="/img/iconsax-linear-notification.svg"
          overlapClassName="header-2"
        />
      </div>
    </div>
  );
};
