import { AutotestingEditor } from ".";

export default {
  title: "Components/AutotestingEditor",
  component: AutotestingEditor,
};

export const Default = {
  args: {
    className: {},
  },
};
