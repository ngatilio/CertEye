import { YamlFile } from ".";

export default {
  title: "Components/YamlFile",
  component: YamlFile,
};

export const Default = {
  args: {
    className: {},
  },
};
